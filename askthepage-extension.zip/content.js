(function() {
  if (document.getElementById('askthepage-floating-widget')) return;

  const ICONS = {
    sparkles: `<svg class="atp-icon atp-icon-small" viewBox="0 0 24 24"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4M3 5h4M19 3v4M17 5h4M5 19v4M3 21h4M19 19v4M17 21h4"/></svg>`,
    brain: `<svg class="atp-icon atp-icon-small" viewBox="0 0 24 24"><path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/><path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/><path d="M17.599 6.5A3 3 0 0 0 13.6 4.4"/><path d="M6.401 6.5A3 3 0 0 1 10.4 4.4"/></svg>`,
    zap: `<svg class="atp-icon atp-icon-small" viewBox="0 0 24 24"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg>`,
    code: `<svg class="atp-icon atp-icon-small" viewBox="0 0 24 24"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
    send: `<svg class="atp-icon atp-icon-small" viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>`,
    x: `<svg class="atp-icon" viewBox="0 0 24 24"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`,
    messageSquare: `<svg class="atp-icon" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`
  };

  const AI_AGENTS = [
    { id: "gpt4", name: "GPT-4", role: "Advanced Reasoning", avatar: "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&w=150&q=80", status: "online", icon: "sparkles", grad: "linear-gradient(to bottom right, rgba(16, 185, 129, 0.2), rgba(52, 211, 153, 0.2))" },
    { id: "claude", name: "Claude 3.5", role: "Creative Writing", avatar: "https://images.unsplash.com/photo-1614729939124-03290b5609ce?auto=format&fit=crop&w=150&q=80", status: "online", icon: "brain", grad: "linear-gradient(to bottom right, rgba(249, 115, 22, 0.2), rgba(251, 191, 36, 0.2))" },
    { id: "gemini", name: "Gemini Pro", role: "Multimodal Analysis", avatar: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=150&q=80", status: "busy", icon: "zap", grad: "linear-gradient(to bottom right, rgba(59, 130, 246, 0.2), rgba(6, 182, 212, 0.2))" },
    { id: "copilot", name: "Copilot", role: "Code Assistant", avatar: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=150&q=80", status: "online", icon: "code", grad: "linear-gradient(to bottom right, rgba(168, 85, 247, 0.2), rgba(139, 92, 246, 0.2))" }
  ];

  let currentAgent = AI_AGENTS[0];
  let isOpen = false;

  const container = document.createElement('div');
  container.id = 'askthepage-floating-widget';
  
  // HTML Template
  container.innerHTML = `
    <div id="atp-chat-window" class="atp-chat-window" style="display: none;">
      <!-- Header -->
      <div class="atp-header">
        <div id="atp-header-gradient" class="atp-header-gradient" style="background: ${currentAgent.grad};"></div>
        <div class="atp-header-content">
          <div class="atp-agent-info">
            <div class="atp-avatar">
              <img id="atp-agent-avatar" src="${currentAgent.avatar}" alt="Avatar">
              <div id="atp-agent-status" class="atp-status-dot"></div>
            </div>
            <div>
              <h3 id="atp-agent-name" class="atp-agent-name">${currentAgent.name}</h3>
              <div id="atp-agent-role" class="atp-agent-role">${currentAgent.role}</div>
            </div>
          </div>
          <button id="atp-close-btn" class="atp-close-btn">${ICONS.x}</button>
        </div>
      </div>
      
      <!-- Selector -->
      <div class="atp-selector">
        <select id="atp-agent-select">
          ${AI_AGENTS.map(a => `<option value="${a.id}">${a.name} - ${a.role}</option>`).join('')}
        </select>
      </div>
      
      <!-- Chat Area -->
      <div id="atp-chat-area" class="atp-chat-area">
        <div class="atp-message-row">
          <img class="atp-msg-avatar" src="${currentAgent.avatar}" alt="AI">
          <div class="atp-msg-content">
            <span class="atp-msg-name">${currentAgent.name}</span>
            <div class="atp-msg-bubble atp-bot-bubble">
              Hello! I'm ${currentAgent.name}. How can I assist you with your project today?
            </div>
          </div>
        </div>
        
        <div class="atp-message-row atp-user-row">
          <div class="atp-avatar" style="width:32px; height:32px; border:none; background:#3b82f6; color:#fff; font-size:10px; font-weight:bold;">ME</div>
          <div class="atp-msg-content">
            <div class="atp-msg-bubble atp-user-bubble">
              I need help optimizing my dashboard performance.
            </div>
          </div>
        </div>
        
        <div class="atp-message-row" id="atp-typing-indicator" style="display: none;">
          <img class="atp-msg-avatar" src="${currentAgent.avatar}" alt="AI">
          <div class="atp-msg-content">
            <div class="atp-msg-bubble atp-bot-bubble atp-typing">
              <span></span><span></span><span></span>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Input Area -->
      <div class="atp-input-area">
        <form id="atp-input-form" class="atp-input-form">
          <input type="text" id="atp-chat-input" placeholder="Message ${currentAgent.name}..." autocomplete="off">
          <button type="submit" id="atp-send-btn" disabled>${ICONS.send}</button>
        </form>
      </div>
    </div>
    
    <button id="atp-toggle-btn" class="atp-toggle-btn">
      <div class="atp-toggle-glow"></div>
      <div id="atp-toggle-icon">${ICONS.messageSquare}</div>
    </button>
  `;

  document.body.appendChild(container);

  // Logic
  const toggleBtn = document.getElementById('atp-toggle-btn');
  const toggleIcon = document.getElementById('atp-toggle-icon');
  const chatWindow = document.getElementById('atp-chat-window');
  const closeBtn = document.getElementById('atp-close-btn');
  const agentSelect = document.getElementById('atp-agent-select');
  const chatInput = document.getElementById('atp-chat-input');
  const sendBtn = document.getElementById('atp-send-btn');
  const chatArea = document.getElementById('atp-chat-area');
  const typingIndicator = document.getElementById('atp-typing-indicator');

  function toggleWidget() {
    isOpen = !isOpen;
    if (isOpen) {
      chatWindow.style.display = 'block';
      // Force reflow
      void chatWindow.offsetWidth;
      chatWindow.classList.add('atp-open');
      toggleBtn.classList.add('atp-open');
      toggleIcon.innerHTML = ICONS.x;
    } else {
      chatWindow.classList.remove('atp-open');
      toggleBtn.classList.remove('atp-open');
      toggleIcon.innerHTML = ICONS.messageSquare;
      setTimeout(() => {
        if (!isOpen) chatWindow.style.display = 'none';
      }, 400); // match transition duration
    }
  }

  toggleBtn.addEventListener('click', toggleWidget);
  closeBtn.addEventListener('click', () => { if(isOpen) toggleWidget(); });

  agentSelect.addEventListener('change', (e) => {
    currentAgent = AI_AGENTS.find(a => a.id === e.target.value);
    
    // Update Header
    document.getElementById('atp-header-gradient').style.background = currentAgent.grad;
    const avatarImg = document.getElementById('atp-agent-avatar');
    avatarImg.src = currentAgent.avatar;
    document.getElementById('atp-agent-name').textContent = currentAgent.name;
    document.getElementById('atp-agent-role').textContent = currentAgent.role;
    
    const statusDot = document.getElementById('atp-agent-status');
    statusDot.style.background = currentAgent.status === 'online' ? '#10b981' : 
                                 currentAgent.status === 'busy' ? '#f59e0b' : '#94a3b8';
                                 
    chatInput.placeholder = `Message ${currentAgent.name}...`;
    
    // Update avatars in chat
    document.querySelectorAll('.atp-msg-avatar').forEach(img => {
      if (img.id !== 'atp-agent-avatar') img.src = currentAgent.avatar;
    });
    document.querySelectorAll('.atp-msg-name').forEach(name => {
      if (name.id !== 'atp-agent-name') name.textContent = currentAgent.name;
    });
  });

  chatInput.addEventListener('input', () => {
    sendBtn.disabled = chatInput.value.trim().length === 0;
  });

  document.getElementById('atp-input-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const msg = chatInput.value.trim();
    if (!msg) return;

    // Add user message
    const userRow = document.createElement('div');
    userRow.className = 'atp-message-row atp-user-row';
    userRow.innerHTML = `
      <div class="atp-avatar" style="width:32px; height:32px; border:none; background:#3b82f6; color:#fff; font-size:10px; font-weight:bold;">ME</div>
      <div class="atp-msg-content">
        <div class="atp-msg-bubble atp-user-bubble">${msg.replace(/</g, "&lt;")}</div>
      </div>
    `;
    chatArea.insertBefore(userRow, typingIndicator);
    
    chatInput.value = '';
    sendBtn.disabled = true;
    chatArea.scrollTop = chatArea.scrollHeight;

    // Simulate typing
    typingIndicator.style.display = 'flex';
    chatArea.scrollTop = chatArea.scrollHeight;
    
    if (window.chrome && chrome.runtime && chrome.runtime.sendMessage) {
      // We are inside the extension! Ask the real Gemini.
      const pageContext = document.body.innerText.substring(0, 30000); // Send up to 30k chars
      chrome.runtime.sendMessage({
        type: 'ASK_GEMINI',
        prompt: msg,
        context: pageContext
      }, (response) => {
        typingIndicator.style.display = 'none';
        
        let replyText = "Sorry, I couldn't get a response.";
        if (response && response.reply) replyText = response.reply;
        if (response && response.error) replyText = "Error: " + response.error;
        
        const botRow = document.createElement('div');
        botRow.className = 'atp-message-row';
        
        // Parse markdown loosely for bold and newlines
        const formattedReply = replyText.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>');
        
        botRow.innerHTML = `
          <img class="atp-msg-avatar" src="${currentAgent.avatar}" alt="AI">
          <div class="atp-msg-content">
            <span class="atp-msg-name">${currentAgent.name}</span>
            <div class="atp-msg-bubble atp-bot-bubble">${formattedReply}</div>
          </div>
        `;
        chatArea.insertBefore(botRow, typingIndicator);
        chatArea.scrollTop = chatArea.scrollHeight;
      });
    } else {
      // We are on the website demo. Just show a mock response.
      setTimeout(() => {
        typingIndicator.style.display = 'none';
        const botRow = document.createElement('div');
        botRow.className = 'atp-message-row';
        botRow.innerHTML = `
          <img class="atp-msg-avatar" src="${currentAgent.avatar}" alt="AI">
          <div class="atp-msg-content">
            <span class="atp-msg-name">${currentAgent.name}</span>
            <div class="atp-msg-bubble atp-bot-bubble">I am a demo mock on the website! If you install the extension, I will use real AI!</div>
          </div>
        `;
        chatArea.insertBefore(botRow, typingIndicator);
        chatArea.scrollTop = chatArea.scrollHeight;
      }, 1500);
    }
  });
})();
