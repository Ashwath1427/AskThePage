if (!window.pageLensInitialized) {
  window.pageLensInitialized = true;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'HIGHLIGHT_CITATION') {
      handleHighlight(msg.blockIds);
      sendResponse({ status: 'success' });
    }
    if (msg.type === 'EXTRACT_PAGE') {
      executeExtraction();
      sendResponse({ status: 'extracting' });
    }
  });

  function executeExtraction() {
    if (typeof window.Extractor !== 'undefined') {
      const data = window.Extractor.extract();
      chrome.runtime.sendMessage({ type: 'PAGE_CONTENT_READY', data: data }).catch(e => console.error(e));
    } else {
      console.error("[ContentScript] Extractor is undefined");
    }
  }

  function handleHighlight(blockIds) {
    if (!blockIds || blockIds.length === 0) return;

    document.querySelectorAll('.pagelens-highlight').forEach(el => {
      el.classList.remove('pagelens-highlight');
      el.style.backgroundColor = '';
      el.style.outline = '';
      el.style.transition = '';
    });

    let firstScrolled = false;

    blockIds.forEach(id => {
      const el = document.querySelector(`[data-pagelens-id="${id}"]`);
      if (el) {
        if (!firstScrolled) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          firstScrolled = true;
        }
        
        el.classList.add('pagelens-highlight');
        const origBg = el.style.backgroundColor;
        const origOutline = el.style.outline;
        
        el.style.transition = 'background-color 0.3s ease, outline 0.3s ease';
        el.style.backgroundColor = '#fef08a';
        el.style.outline = '2px solid #eab308';

        setTimeout(() => {
          el.style.backgroundColor = origBg;
          el.style.outline = origOutline;
          el.classList.remove('pagelens-highlight');
        }, 3000);
      }
    });
  }

  // Trigger extraction immediately upon injection
  executeExtraction();
} else {
  // If already initialized, just trigger extraction again
  if (typeof window.Extractor !== 'undefined') {
    const data = window.Extractor.extract();
    chrome.runtime.sendMessage({ type: 'PAGE_CONTENT_READY', data: data }).catch(e => console.error(e));
  }
}
