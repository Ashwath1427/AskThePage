if (!window.pageLensInitialized) {
  window.pageLensInitialized = true;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'HIGHLIGHT_CITATION') {
      handleHighlight(msg.blockIds);
      sendResponse({ status: 'success' });
    }
    if (msg.type === 'EXTRACT_PAGE') {
      executeExtraction();
      sendResponse({ status: 'extracting' });
    }
  });

  function executeExtraction() {
    if (typeof window.Extractor !== 'undefined') {
      const data = window.Extractor.extract();
      chrome.runtime.sendMessage({ type: 'PAGE_CONTENT_READY', data: data }).catch(e => console.error(e));
    } else {
      console.error("[ContentScript] Extractor is undefined");
    }
  }

  function handleHighlight(blockIds) {
    if (!blockIds || blockIds.length === 0) return;

    document.querySelectorAll('.pagelens-highlight').forEach(el => {
      el.classList.remove('pagelens-highlight');
      el.style.removeProperty('background-color');
      el.style.removeProperty('outline');
      el.style.removeProperty('box-shadow');
      el.style.removeProperty('transition');
    });

    let firstScrolled = false;

    blockIds.forEach(id => {
      const el = document.querySelector(`[data-pagelens-id="${id}"]`);
      if (el) {
        if (!firstScrolled) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          firstScrolled = true;
        }
        
        el.classList.add('pagelens-highlight');
        const origBg = el.style.backgroundColor;
        const origOutline = el.style.outline;
        const origShadow = el.style.boxShadow;
        
        el.style.setProperty('transition', 'all 0.3s ease', 'important');
        el.style.setProperty('background-color', '#fef08a', 'important');
        el.style.setProperty('outline', '3px solid #eab308', 'important');
        el.style.setProperty('box-shadow', '0 0 15px rgba(234, 179, 8, 0.7)', 'important');

        setTimeout(() => {
          if (origBg) el.style.backgroundColor = origBg;
          else el.style.removeProperty('background-color');
          
          if (origOutline) el.style.outline = origOutline;
          else el.style.removeProperty('outline');
          
          if (origShadow) el.style.boxShadow = origShadow;
          else el.style.removeProperty('box-shadow');
          
          el.classList.remove('pagelens-highlight');
        }, 3000);
      }
    });
  }

  // Trigger extraction immediately upon injection
  executeExtraction();
} else {
  // If already initialized, just trigger extraction again
  if (typeof window.Extractor !== 'undefined') {
    const data = window.Extractor.extract();
    chrome.runtime.sendMessage({ type: 'PAGE_CONTENT_READY', data: data }).catch(e => console.error(e));
  }
}
