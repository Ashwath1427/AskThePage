chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error("Error setting panel behavior:", error));
});
// The service worker routes messages if needed, but sidepanel and content script can also talk directly
// once the sidepanel is open.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PAGE_CONTENT_READY') {
    // Just logging in service worker for debug
    console.log("[ServiceWorker] Received PAGE_CONTENT_READY from tab:", sender.tab?.id);
  }
});
