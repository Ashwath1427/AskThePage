let currentExtractedData = null;
let currentChunks = [];
let cachedWebsiteChunks = null;
let currentLinks = [];
let activeTabId = null;
let activeTabUrl = null;

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initSettings();
  initSummary();
  initAsk();
  initCitationClicks();

  loadActiveTab();

  chrome.tabs.onActivated.addListener(() => {
    loadActiveTab();
  });
  
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.active) {
      loadActiveTab();
    }
  });

function loadActiveTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    
    if (!tab) {
      showGlobalError("No active tab found.");
      return;
    }
    
    if (tab.id === activeTabId && tab.url === activeTabUrl) return;
    
    if (typeof tab.url !== "string" || !tab.url) {
      showGlobalError("Unable to read current tab URL.");
      return;
    }
    
    const restrictedPrefixes = ["chrome://", "chrome-extension://", "edge://", "about:", "devtools://"];
    if (restrictedPrefixes.some(prefix => tab.url.startsWith(prefix))) {
      showGlobalError("AskThePage cannot read this type of page.");
      return;
    }

    activeTabId = tab.id;
    activeTabUrl = tab.url;
    
    const statusEl = document.getElementById('status-indicator');
    if (statusEl) {
      statusEl.textContent = 'Extracting...';
      statusEl.className = 'status extracting';
    }
    const chatBox = document.getElementById('chat-messages');
    if (chatBox) chatBox.innerHTML = '';
    const summaryBox = document.getElementById('summary-result');
    if (summaryBox) summaryBox.innerHTML = '';
    const errBox = document.getElementById('summary-error');
    if (errBox) errBox.classList.add('hidden');

    const statSource = document.getElementById('stat-source');
    if (statSource) {
      try {
        statSource.textContent = new URL(tab.url).hostname;
      } catch (e) {
        statSource.textContent = "Unknown source";
      }
    }

    const welcomeMsg = document.getElementById('welcome-msg');
    if (welcomeMsg && tab.title) {
      let shortTitle = tab.title;
      if (shortTitle.length > 35) shortTitle = shortTitle.substring(0, 35) + "...";
      welcomeMsg.textContent = `Hi! I've read "${shortTitle}". What would you like to know?`;
    }
    
    chrome.scripting.executeScript({
      target: { tabId: activeTabId },
      files: ['lib/readability.min.js', 'lib/extractor.js', 'content-script.js']
    }).catch(err => {
      showGlobalError("Failed to inject extraction script: " + err.message);
    });
  });
}

  // 3. Listen for data coming back from content-script
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'PAGE_CONTENT_READY') {
      setupData(msg.data);
    }
  });

  // 4. Initialize Deep Scan button
  document.getElementById('btn-deep-scan').addEventListener('click', async (e) => {
    const btn = e.target;
    if (cachedWebsiteChunks) return; // Already scanned
    
    btn.disabled = true;
    btn.textContent = "Scanning Site...";
    
    if (!currentLinks || currentLinks.length === 0) {
      btn.textContent = "No Pages Found";
      setTimeout(() => {
        btn.textContent = "Deep Scan";
        btn.disabled = false;
      }, 2000);
      return;
    }
    
    try {
      const allChunks = [...currentChunks]; 
      // Fetch up to 10 internal pages concurrently with timeout
      const fetchWithTimeout = (url, ms = 10000) => {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), ms);
        return fetch(url, { signal: controller.signal })
          .then(res => res.text())
          .then(html => { clearTimeout(timer); return {url, html}; })
          .catch(() => { clearTimeout(timer); return null; });
      };
      
      const fetchPromises = currentLinks.slice(0, 10).map(url => fetchWithTimeout(url));
      const results = await Promise.all(fetchPromises);
      
      let pagesScanned = 0;
      for (const res of results) {
        if (!res) continue;
        const parser = new DOMParser();
        const doc = parser.parseFromString(res.html, 'text/html');
        const data = Extractor.extract(doc.body, res.url, doc.title);
        if (data.blocks && data.blocks.length > 0) {
          const pageChunks = Chunker.chunkBlocks(data.blocks);
          allChunks.push(...pageChunks);
          pagesScanned++;
        }
      }
      
      if (pagesScanned > 0) {
        cachedWebsiteChunks = allChunks;
        currentChunks = cachedWebsiteChunks;
        btn.textContent = `Scanned ${pagesScanned} pages ✓`;
      } else {
        btn.textContent = "No Extra Content";
        setTimeout(() => {
          btn.textContent = "Deep Scan";
          btn.disabled = false;
        }, 2000);
      }
      
      const statChunks = document.getElementById('stat-chunks');
      if (statChunks) statChunks.textContent = `${currentChunks.length} chunks${pagesScanned > 0 ? ' (Full Site)' : ''}`;
      
    } catch(err) {
      console.error(err);
      btn.textContent = "Scan Failed";
      setTimeout(() => {
        btn.textContent = "Deep Scan";
        btn.disabled = false;
      }, 2000);
    }
  });
});

function setupData(data) {
  if (!data || !data.blocks || data.blocks.length === 0) {
    showGlobalError("No readable content found on this page.");
    disableApp();
    return;
  }
  
  currentExtractedData = data;
  currentChunks = Chunker.chunkBlocks(data.blocks);
  currentLinks = data.links || [];
  cachedWebsiteChunks = null; // Reset cache for new page
  
  if (currentLinks.length > 0) {
    document.getElementById('btn-deep-scan').classList.remove('hidden');
    document.getElementById('btn-deep-scan').disabled = false;
    document.getElementById('btn-deep-scan').textContent = "Deep Scan Website";
  } else {
    // Still show button but with different text - some links may load dynamically
    document.getElementById('btn-deep-scan').classList.remove('hidden');
    document.getElementById('btn-deep-scan').disabled = false;
    document.getElementById('btn-deep-scan').textContent = "Deep Scan";
  }
  
  const statusEl = document.getElementById('status-indicator');
  statusEl.textContent = 'Page Ready';
  statusEl.className = 'status ready';
  
  const statChunks = document.getElementById('stat-chunks');
  if (statChunks) statChunks.textContent = `${currentChunks.length} chunks`;
  enableApp();
}

function showGlobalError(msg) {
  const statusEl = document.getElementById('status-indicator');
  statusEl.textContent = 'Error';
  statusEl.className = 'status error';
  
  const errorBox = document.getElementById('summary-error');
  errorBox.textContent = msg;
  errorBox.classList.remove('hidden');
  disableApp();
}

function disableApp() {
  document.getElementById('btn-summarize').disabled = true;
  document.getElementById('btn-ask').disabled = true;
  document.getElementById('question-input').disabled = true;
}

function enableApp() {
  document.getElementById('btn-summarize').disabled = false;
  document.getElementById('btn-ask').disabled = false;
  document.getElementById('question-input').disabled = false;
  document.getElementById('summary-error').classList.add('hidden');
}

// === TABS ===
function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });
}

// === SETTINGS ===
function initSettings() {
  const detailInput = document.getElementById('setting-detail');
  const personaInput = document.getElementById('setting-persona');
  const apiKeyInput = document.getElementById('setting-api-key');
  const limitDisplay = document.getElementById('free-limit-display');
  
  function updateLimitDisplay(key, used) {
    if (!limitDisplay) return;
    if (key === 'APASAA') {
      limitDisplay.textContent = "PREMIUM (Unlimited)";
      limitDisplay.style.color = "#a78bfa";
    } else {
      const left = Math.max(0, 8 - (used || 0));
      limitDisplay.textContent = `${left} / 8 Left`;
      limitDisplay.style.color = left === 0 ? "#f87171" : "#4ade80";
    }
  }

  chrome.storage.local.get(['answerDetail', 'userPersona', 'geminiApiKey', 'freeGenerationsUsed'], (res) => {
    if (res.answerDetail) detailInput.value = res.answerDetail;
    if (res.userPersona) personaInput.value = res.userPersona;
    if (res.geminiApiKey) apiKeyInput.value = res.geminiApiKey;
    updateLimitDisplay(res.geminiApiKey, res.freeGenerationsUsed);
  });
  
  document.getElementById('btn-save-settings').addEventListener('click', () => {
    const key = apiKeyInput.value.trim();
    
    // Check if they entered an API key and if it's valid
    if (key && key !== 'APASAA' && !key.startsWith('AIzaSy')) {
      const statusObj = document.getElementById('settings-status');
      statusObj.classList.add('error');
      statusObj.textContent = "Invalid API Key. Please provide a valid one.";
      setTimeout(() => {
        statusObj.textContent = "";
        statusObj.classList.remove('error');
      }, 4000);
      return;
    }

    chrome.storage.local.set({ 
      answerDetail: detailInput.value,
      userPersona: personaInput.value.trim(),
      geminiApiKey: key
    }, () => {
      const statusObj = document.getElementById('settings-status');
      statusObj.classList.remove('error');
      statusObj.textContent = "Saved securely to local storage!";
      
      chrome.storage.local.get(['freeGenerationsUsed'], (res) => {
        updateLimitDisplay(key, res.freeGenerationsUsed);
      });

      setTimeout(() => statusObj.textContent = "", 2000);
    });
  });
}

// === SUMMARY ===
function initSummary() {
  const btn = document.getElementById('btn-summarize');
  btn.addEventListener('click', async () => {
    if (!currentExtractedData || !currentChunks) return;
    
    btn.disabled = true;
    btn.textContent = 'Generating...';
    document.getElementById('summary-error').classList.add('hidden');
    
    try {
      const type = document.getElementById('summary-type').value;
      const result = await ApiClient.generateSummary(currentChunks, type);
      
      let html = result.summary || "";
      if (result.citations && result.citations.length > 0) {
        html = Citations.injectInlineCitations(html, result.citations, currentChunks);
        // Citation cards removed as per user request
      }
      document.getElementById('summary-result').innerHTML = html;
    } catch (e) {
      document.getElementById('summary-error').textContent = e.message;
      document.getElementById('summary-error').classList.remove('hidden');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Generate';
    }
  });
}

// === ASK ===
function initAsk() {
  const btn = document.getElementById('btn-ask');
  const input = document.getElementById('question-input');
  
  btn.addEventListener('click', handleAsk);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  });
}

async function handleAsk() {
  const input = document.getElementById('question-input');
  const q = input.value.trim();
  if (!q || !currentExtractedData) return;
  
  input.value = '';
  appendMessage('user', q);
  
  const btn = document.getElementById('btn-ask');
  btn.disabled = true;
  document.getElementById('ask-error').classList.add('hidden');
  
  const topChunks = Ranker.rankChunks(q, currentChunks, 15);
  
  // Create a loading message bubble
  const loadingId = 'loading-' + Date.now();
  const loadingHtml = `<div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>`;
  appendMessage('bot', loadingHtml, true, loadingId);
  
  chrome.storage.local.get(['answerDetail', 'userPersona'], async (res) => {
    try {
      const result = await ApiClient.answerQuestion(q, topChunks, res.answerDetail, res.userPersona);
      
      // Remove loading bubble
      const loadingEl = document.getElementById(loadingId);
      if (loadingEl) loadingEl.remove();
      
      let html = result.answer;
      
      if (result.not_on_page) {
        html += "<br><br><i>(Note: This information was not explicitly found in the page text.)</i>";
      } else if (result.citations && result.citations.length > 0) {
        html = Citations.injectInlineCitations(html, result.citations, currentChunks);
      }
      
      appendMessage('bot', html, true);
      btn.disabled = false;
    } catch (e) {
      // Remove loading bubble
      const loadingEl = document.getElementById(loadingId);
      if (loadingEl) loadingEl.remove();
      
      document.getElementById('ask-error').textContent = e.message;
      document.getElementById('ask-error').classList.remove('hidden');
      btn.disabled = false;
    }
  });
}

function appendMessage(role, textOrHtml, isHtml = false, id = null) {
  const hist = document.getElementById('chat-history');
  
  const div = document.createElement('div');
  div.className = `message ${role}`;
  if (id) div.id = id;
  
  const contentDiv = document.createElement('div');
  contentDiv.className = 'message-content';
  
  if (isHtml) contentDiv.innerHTML = textOrHtml;
  else contentDiv.textContent = textOrHtml;
  
  div.appendChild(contentDiv);
  hist.appendChild(div);
  hist.scrollTop = hist.scrollHeight;
}

// === CITATION CLICKS ===
function initCitationClicks() {
  document.addEventListener('click', (e) => {
    const chip = e.target.closest('.citation-chip');
    if (!chip || !activeTabId) return;
    
    const blockIdsStr = chip.getAttribute('data-blocks');
    const urlStr = chip.getAttribute('data-url');
    
    if (!blockIdsStr) {
      alert("Source text not found. This information might have been inferred from general context.");
      return;
    }
    
    chrome.tabs.get(activeTabId, (tab) => {
      let isDifferent = false;
      if (urlStr) {
        try {
          const u1 = new URL(urlStr);
          const u2 = new URL(tab.url);
          isDifferent = (u1.origin + u1.pathname) !== (u2.origin + u2.pathname);
        } catch(e) {
          isDifferent = urlStr !== tab.url;
        }
      }

      if (isDifferent) {
        chrome.tabs.update(activeTabId, { url: urlStr });
        return;
      }
      
      const blockIds = blockIdsStr.split(',');
      chrome.tabs.sendMessage(activeTabId, {
        type: 'HIGHLIGHT_CITATION',
        blockIds: blockIds
      });
    });
  });
}

// === QUIZ LOGIC ===
let currentQuizData = null;
let currentQuizType = 'mcq';

// Update Slider Labels
const diffSlider = document.getElementById('quiz-difficulty');
const diffVal = document.getElementById('difficulty-val');
const btnMinus = document.getElementById('btn-diff-minus');
const btnPlus = document.getElementById('btn-diff-plus');

function updateDiff() {
  const val = parseInt(diffSlider.value, 10);
  if (val === 1) diffVal.textContent = 'Easy';
  else if (val === 2) diffVal.textContent = 'Medium';
  else diffVal.textContent = 'Hard';
  
  btnMinus.disabled = val <= 1;
  btnPlus.disabled = val >= 3;
  
  // Dynamic gradient fill for the track (Shadcn style)
  const percentage = ((val - 1) / 2) * 100;
  diffSlider.style.background = `linear-gradient(to right, white ${percentage}%, rgba(255, 255, 255, 0.15) ${percentage}%)`;
}

diffSlider.addEventListener('input', updateDiff);

btnMinus.addEventListener('click', () => {
  diffSlider.value = Math.max(1, parseInt(diffSlider.value, 10) - 1);
  updateDiff();
});

btnPlus.addEventListener('click', () => {
  diffSlider.value = Math.min(3, parseInt(diffSlider.value, 10) + 1);
  updateDiff();
});

updateDiff();

const countSlider = document.getElementById('quiz-count');

document.getElementById('btn-generate-quiz').addEventListener('click', async () => {
  const btn = document.getElementById('btn-generate-quiz');
  const errorDiv = document.getElementById('quiz-error');
  const container = document.getElementById('quiz-container');
  const questionsDiv = document.getElementById('quiz-questions');
  const scoreDiv = document.getElementById('quiz-score');

  if (currentChunks.length === 0) {
    errorDiv.textContent = "No page content available to generate a quiz.";
    errorDiv.classList.remove('hidden');
    return;
  }

  const numQ = parseInt(countSlider.value, 10) || 5;
  const diff = diffSlider.value;
  currentQuizType = document.getElementById('quiz-type').value;

  errorDiv.classList.add('hidden');
  container.classList.add('hidden');
  scoreDiv.classList.add('hidden');
  btn.disabled = true;
  btn.textContent = "Generating Quiz...";

  try {
    currentQuizData = await ApiClient.generateQuiz(currentChunks, numQ, diff, currentQuizType);
    
    // Render Quiz
    questionsDiv.innerHTML = '';
    currentQuizData.forEach((q, qIndex) => {
      const card = document.createElement('div');
      card.className = 'quiz-question-card';
      
      const title = document.createElement('div');
      title.className = 'quiz-question-text';
      title.textContent = `${qIndex + 1}. ${q.question}`;
      card.appendChild(title);
      
      if (currentQuizType === 'mcq') {
        const optionsContainer = document.createElement('div');
        optionsContainer.className = 'quiz-options-container';
        
        q.options.forEach((optText, oIndex) => {
          const optDiv = document.createElement('label');
          optDiv.className = 'quiz-option';
          
          const radio = document.createElement('input');
          radio.type = 'radio';
          radio.name = `question-${qIndex}`;
          radio.value = oIndex;
          
          radio.addEventListener('change', () => {
            // Highlight selected
            const siblings = optionsContainer.querySelectorAll('.quiz-option');
            siblings.forEach(s => s.classList.remove('selected'));
            if (radio.checked) optDiv.classList.add('selected');
          });
          
          optDiv.appendChild(radio);
          optDiv.appendChild(document.createTextNode(optText));
          optionsContainer.appendChild(optDiv);
        });
        card.appendChild(optionsContainer);
      } else {
        const textArea = document.createElement('textarea');
        textArea.className = 'quiz-textarea';
        textArea.placeholder = 'Type your answer here...';
        textArea.id = `question-open-${qIndex}`;
        card.appendChild(textArea);
      }
      
      const explanation = document.createElement('div');
      explanation.className = 'quiz-explanation hidden';
      if (currentQuizType === 'mcq') {
        explanation.textContent = q.explanation;
      } else {
        explanation.innerHTML = `<strong>Correct Answer:</strong> ${q.correctAnswer}<br><br><strong>Explanation:</strong> ${q.explanation}`;
      }
      card.appendChild(explanation);
      
      questionsDiv.appendChild(card);
    });
    
    document.getElementById('btn-submit-quiz').disabled = false;
    document.getElementById('btn-submit-quiz').classList.remove('hidden');
    container.classList.remove('hidden');
  } catch (e) {
    errorDiv.textContent = e.message;
    errorDiv.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = "Generate New Quiz";
  }
});

document.getElementById('btn-submit-quiz').addEventListener('click', () => {
  if (!currentQuizData) return;
  
  const cards = document.querySelectorAll('.quiz-question-card');
  
  // 1. Validation phase
  let allAnswered = true;
  cards.forEach(card => {
    if (currentQuizType === 'mcq') {
      if (!card.querySelector('input[type="radio"]:checked')) allAnswered = false;
    } else {
      const textArea = card.querySelector('textarea');
      if (textArea.value.trim() === '') allAnswered = false;
    }
  });
  
  if (!allAnswered) {
    alert("Please answer all questions before submitting!");
    return;
  }
  
  // 2. Grading phase
  let score = 0;
  
  cards.forEach((card, qIndex) => {
    if (currentQuizType === 'mcq') {
      const selectedRadio = card.querySelector('input[type="radio"]:checked');
      const selectedValue = parseInt(selectedRadio.value, 10);
      const correctValue = currentQuizData[qIndex].correctIndex;
      
      // Lock inputs
      const radios = card.querySelectorAll('input[type="radio"]');
      radios.forEach(r => r.disabled = true);
      
      // Highlight correct / incorrect
      const options = card.querySelectorAll('.quiz-option');
      options.forEach((opt, oIndex) => {
        opt.classList.remove('selected');
        if (oIndex === correctValue) {
          opt.classList.add('correct');
        } else if (oIndex === selectedValue && selectedValue !== correctValue) {
          opt.classList.add('incorrect');
        }
      });
      
      if (selectedValue === correctValue) {
        score++;
      }
    } else {
      // For open ended, we just lock the textarea
      const textArea = card.querySelector('textarea');
      textArea.disabled = true;
    }
    
    // Show explanation
    const explanation = card.querySelector('.quiz-explanation');
    explanation.classList.remove('hidden');
  });
  
  const scoreDiv = document.getElementById('quiz-score');
  if (currentQuizType === 'mcq') {
    scoreDiv.textContent = `You scored ${score} out of ${currentQuizData.length}!`;
  } else {
    scoreDiv.textContent = `Answers revealed! Please review your answers against the correct ones.`;
  }
  
  scoreDiv.classList.remove('hidden');
  document.getElementById('btn-submit-quiz').classList.add('hidden');
});
