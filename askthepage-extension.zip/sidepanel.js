let currentExtractedData = null;
let currentChunks = [];
let activeTabId = null;

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initSettings();
  initSummary();
  initAsk();
  initCitationClicks();

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    
    if (!tab) {
      showGlobalError("No active tab found.");
      return;
    }
    
    if (typeof tab.url !== "string" || !tab.url) {
      showGlobalError("Unable to read current tab URL. (Try clicking the extension icon again to grant permission)");
      return;
    }
    
    const restrictedPrefixes = [
      "chrome://",
      "chrome-extension://",
      "edge://",
      "about:",
      "devtools://"
    ];
    
    if (restrictedPrefixes.some(prefix => tab.url.startsWith(prefix))) {
      showGlobalError("AskThePage cannot read this type of page.");
      return;
    }

    activeTabId = tab.id;
    const statSource = document.getElementById('stat-source');
    if (statSource) {
      try {
        statSource.textContent = new URL(tab.url).hostname;
      } catch (e) {
        statSource.textContent = "Unknown source";
      }
    }

    const welcomeMsg = document.getElementById('welcome-msg');
    if (welcomeMsg && tab.title) {
      let shortTitle = tab.title;
      if (shortTitle.length > 35) shortTitle = shortTitle.substring(0, 35) + "...";
      welcomeMsg.textContent = `Hi! I've read "${shortTitle}". What would you like to know?`;
    }
    
    // 2. Inject scripts and request extraction
    chrome.scripting.executeScript({
      target: { tabId: activeTabId },
      files: ['lib/readability.min.js', 'lib/extractor.js', 'content-script.js']
    }).catch(err => {
      showGlobalError("Failed to inject extraction script: " + err.message);
    });
  });

  // 3. Listen for data coming back from content-script
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'PAGE_CONTENT_READY') {
      setupData(msg.data);
    }
  });


});

function setupData(data) {
  if (!data || !data.blocks || data.blocks.length === 0) {
    showGlobalError("No readable content found on this page.");
    disableApp();
    return;
  }
  
  currentExtractedData = data;
  currentChunks = Chunker.chunkBlocks(data.blocks);
  
  const statusEl = document.getElementById('status-indicator');
  statusEl.textContent = 'Page Ready';
  statusEl.className = 'status ready';
  
  const statChunks = document.getElementById('stat-chunks');
  if (statChunks) statChunks.textContent = `${currentChunks.length} chunks`;
  enableApp();
}

function showGlobalError(msg) {
  const statusEl = document.getElementById('status-indicator');
  statusEl.textContent = 'Error';
  statusEl.className = 'status error';
  
  const errorBox = document.getElementById('summary-error');
  errorBox.textContent = msg;
  errorBox.classList.remove('hidden');
  disableApp();
}

function disableApp() {
  document.getElementById('btn-summarize').disabled = true;
  document.getElementById('btn-ask').disabled = true;
  document.getElementById('question-input').disabled = true;
}

function enableApp() {
  document.getElementById('btn-summarize').disabled = false;
  document.getElementById('btn-ask').disabled = false;
  document.getElementById('question-input').disabled = false;
  document.getElementById('summary-error').classList.add('hidden');
}

// === TABS ===
function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });
}

// === SETTINGS ===
function initSettings() {
  const detailInput = document.getElementById('setting-detail');
  const personaInput = document.getElementById('setting-persona');
  const apiKeyInput = document.getElementById('setting-api-key');
  const limitDisplay = document.getElementById('free-limit-display');
  
  function updateLimitDisplay(key, used) {
    if (!limitDisplay) return;
    if (key === 'APASAA') {
      limitDisplay.textContent = "PREMIUM (Unlimited)";
      limitDisplay.style.color = "#a78bfa";
    } else {
      const left = Math.max(0, 8 - (used || 0));
      limitDisplay.textContent = `${left} / 8 Left`;
      limitDisplay.style.color = left === 0 ? "#f87171" : "#4ade80";
    }
  }

  chrome.storage.local.get(['answerDetail', 'userPersona', 'geminiApiKey', 'freeGenerationsUsed'], (res) => {
    if (res.answerDetail) detailInput.value = res.answerDetail;
    if (res.userPersona) personaInput.value = res.userPersona;
    if (res.geminiApiKey) apiKeyInput.value = res.geminiApiKey;
    updateLimitDisplay(res.geminiApiKey, res.freeGenerationsUsed);
  });
  
  // Listen for background usage updates so the limit updates live while chatting!
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.freeGenerationsUsed) {
      chrome.storage.local.get(['geminiApiKey'], (res) => {
        updateLimitDisplay(res.geminiApiKey, changes.freeGenerationsUsed.newValue);
      });
    }
  });
  
  document.getElementById('btn-save-settings').addEventListener('click', () => {
    const key = apiKeyInput.value.trim();
    
    // Check if they entered an API key and if it's valid
    if (key && key !== 'APASAA' && !key.startsWith('AIzaSy')) {
      const statusObj = document.getElementById('settings-status');
      statusObj.classList.add('error');
      statusObj.textContent = "Invalid API Key. Please provide a valid one.";
      setTimeout(() => {
        statusObj.textContent = "";
        statusObj.classList.remove('error');
      }, 4000);
      return;
    }

    chrome.storage.local.set({ 
      answerDetail: detailInput.value,
      userPersona: personaInput.value.trim(),
      geminiApiKey: key
    }, () => {
      const statusObj = document.getElementById('settings-status');
      statusObj.classList.remove('error');
      statusObj.textContent = "Saved securely to local storage!";
      
      chrome.storage.local.get(['freeGenerationsUsed'], (res) => {
        updateLimitDisplay(key, res.freeGenerationsUsed);
      });

      setTimeout(() => statusObj.textContent = "", 2000);
    });
  });
}

// === SUMMARY ===
function initSummary() {
  const btn = document.getElementById('btn-summarize');
  btn.addEventListener('click', async () => {
    if (!currentExtractedData || !currentChunks) return;
    
    btn.disabled = true;
    btn.textContent = 'Generating...';
    document.getElementById('summary-error').classList.add('hidden');
    
    try {
      const type = document.getElementById('summary-type').value;
      const result = await ApiClient.generateSummary(currentChunks, type);
      
      let html = result.summary;
      if (result.citations && result.citations.length > 0) {
        html = Citations.injectInlineCitations(html, result.citations, currentChunks);
        html += Citations.renderCitationCards(result.citations, currentChunks);
      }
      document.getElementById('summary-result').innerHTML = html;
    } catch (e) {
      document.getElementById('summary-error').textContent = e.message;
      document.getElementById('summary-error').classList.remove('hidden');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Generate';
    }
  });
}

// === ASK ===
function initAsk() {
  const btn = document.getElementById('btn-ask');
  const input = document.getElementById('question-input');
  
  btn.addEventListener('click', handleAsk);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  });
}

async function handleAsk() {
  const input = document.getElementById('question-input');
  const q = input.value.trim();
  if (!q || !currentExtractedData) return;
  
  input.value = '';
  appendMessage('user', q);
  
  const btn = document.getElementById('btn-ask');
  btn.disabled = true;
  document.getElementById('ask-error').classList.add('hidden');
  
  const topChunks = Ranker.rankChunks(q, currentChunks, 8);
  
    chrome.storage.local.get(['answerDetail', 'userPersona'], async (res) => {
    try {
      const result = await ApiClient.answerQuestion(q, topChunks, res.answerDetail, res.userPersona);
      let html = result.answer;
      
      if (result.not_on_page) {
        html += "<br><br><i>(Note: This information was not explicitly found in the page text.)</i>";
      } else if (result.citations && result.citations.length > 0) {
        html = Citations.injectInlineCitations(html, result.citations, currentChunks);
        html += Citations.renderCitationCards(result.citations, currentChunks);
      }
      
      appendMessage('bot', html, true);
    } catch (e) {
      document.getElementById('ask-error').textContent = e.message;
      document.getElementById('ask-error').classList.remove('hidden');
    } finally {
      btn.disabled = false;
    }
  });
}

function appendMessage(role, textOrHtml, isHtml = false) {
  const hist = document.getElementById('chat-history');
  const div = document.createElement('div');
  div.className = `message ${role}`;
  
  const contentDiv = document.createElement('div');
  contentDiv.className = 'message-content';
  
  if (isHtml) contentDiv.innerHTML = textOrHtml;
  else contentDiv.textContent = textOrHtml;
  
  div.appendChild(contentDiv);
  hist.appendChild(div);
  hist.scrollTop = hist.scrollHeight;
}

// === CITATION CLICKS ===
function initCitationClicks() {
  document.addEventListener('click', (e) => {
    const chip = e.target.closest('.citation-chip');
    if (!chip || !activeTabId) return;
    
    const blockIdsStr = chip.getAttribute('data-blocks');
    if (!blockIdsStr) return;
    
    const blockIds = blockIdsStr.split(',');
    
    chrome.tabs.sendMessage(activeTabId, {
      type: 'HIGHLIGHT_CITATION',
      blockIds: blockIds
    });
  });
}
